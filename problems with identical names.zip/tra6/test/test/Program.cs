﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10;
            int y = 5;
            Console.WriteLine((y-x)==5);
            Console.WriteLine((y*x)>=150);
            Console.WriteLine();
            Console.WriteLine(x==y);
        }
    }
}
